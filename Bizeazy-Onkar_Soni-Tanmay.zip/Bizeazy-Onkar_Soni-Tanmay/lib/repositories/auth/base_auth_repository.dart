import 'package:firebase_auth/firebase_auth.dart' as auth;

abstract class BaseAuthRepository {
  Stream<auth.User?> get user;
  Future<auth.UserCredential> createUserWithEmailAndPassword(
      {required String email, required String password});
  Future<bool> checkUserDataExists({required String userId});
  Future<void> storeUser({required auth.UserCredential credential});
  Future<auth.UserCredential> loginWithEmailAndPassword(
      {required String email, required String password});
  Future<void> logOut();
}
