//Top level Collection
class Paths {
  static const users = 'users';
}
