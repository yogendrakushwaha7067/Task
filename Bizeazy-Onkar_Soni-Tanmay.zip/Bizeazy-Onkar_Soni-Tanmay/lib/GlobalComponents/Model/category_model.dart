class CategoryModel {
  late String categoryName;

  CategoryModel(this.categoryName);

  CategoryModel.fromJson(Map<dynamic, dynamic> json)
      : categoryName = json['categoryName'] as String;

  Map<dynamic, dynamic> toJson() => <dynamic, dynamic>{
        'categoryName': categoryName,
      };
}
