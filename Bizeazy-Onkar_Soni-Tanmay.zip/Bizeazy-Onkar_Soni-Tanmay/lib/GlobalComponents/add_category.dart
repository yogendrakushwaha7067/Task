import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/GlobalComponents/Model/category_model.dart';
import 'package:mobile_pos/GlobalComponents/button_global.dart';
import 'package:mobile_pos/constant.dart';
import 'package:nb_utils/nb_utils.dart';

class AddCategory extends StatefulWidget {
  const AddCategory({Key? key}) : super(key: key);

  @override
  _AddCategoryState createState() => _AddCategoryState();
}

class _AddCategoryState extends State<AddCategory> {
  bool showProgress = false;
  late String categoryName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: const Image(
              image: AssetImage('images/x.png'),
            )),
        title: Text(
          'Add Category',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Visibility(
              visible: showProgress,
              child: const CircularProgressIndicator(
                color: kMainColor,
                strokeWidth: 5.0,
              ),
            ),
            AppTextField(
              textFieldType: TextFieldType.NAME,
              onChanged: (value) {
                setState(() {
                  categoryName = value;
                });
              },
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Fashion',
                floatingLabelBehavior: FloatingLabelBehavior.always,
                labelText: 'Category name',
              ),
            ),
            ButtonGlobalWithoutIcon(
              buttontext: 'Save',
              buttonDecoration: kButtonDecoration.copyWith(color: kMainColor),
              onPressed: () async {
                setState(() {
                  showProgress = true;
                });
                final DatabaseReference _categoryInformationRef =
                FirebaseDatabase.instance
                    .reference()
                    .child(FirebaseAuth.instance.currentUser!.uid)
                    .child('Categories');
                CategoryModel categoryModel = CategoryModel(categoryName);
                await _categoryInformationRef.push().set(categoryModel.toJson());
                setState(() {
                  showProgress = false;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text("Data Saved Successfully")));
                });

                // Navigator.pushNamed(context, '/otp');
              },
              buttonTextColor: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
