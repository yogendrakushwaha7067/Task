import 'package:equatable/equatable.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:mobile_pos/Screens/Authentication/forgot_password.dart';
import 'package:mobile_pos/Screens/Authentication/login_form.dart';
import 'package:mobile_pos/Screens/Authentication/otp_page.dart';
import 'package:mobile_pos/Screens/Authentication/register_form.dart';
import 'package:mobile_pos/Screens/Authentication/sign_in.dart';
import 'package:mobile_pos/Screens/Authentication/success_screen.dart';
import 'package:mobile_pos/Screens/Calculator/calculator.dart';
import 'package:mobile_pos/Screens/Customers/contact_list.dart';
import 'package:mobile_pos/Screens/Delivery/delivery_address_list.dart';
import 'package:mobile_pos/Screens/Expense/expense_list.dart';
import 'package:mobile_pos/Screens/Home/home.dart';
import 'package:mobile_pos/Screens/Marketing/marketing_screen.dart';
import 'package:mobile_pos/Screens/Payment/payment_options.dart';
import 'package:mobile_pos/Screens/Products/add_product.dart';
import 'package:mobile_pos/Screens/Profile/profile_screen.dart';
import 'package:mobile_pos/Screens/Purchase/purchase_contact.dart';
import 'package:mobile_pos/Screens/Purchase/purchase_screen.dart';
import 'package:mobile_pos/Screens/Report/reports.dart';
import 'package:mobile_pos/Screens/Sales/add_discount.dart';
import 'package:mobile_pos/Screens/Sales/add_promo_code.dart';
import 'package:mobile_pos/Screens/Sales/sales_contact.dart';
import 'package:mobile_pos/Screens/Sales/sales_details.dart';
import 'package:mobile_pos/Screens/Sales/sales_list.dart';
import 'package:mobile_pos/Screens/Sales/sales_screen.dart';
import 'package:mobile_pos/Screens/Sales/stock_list.dart';
import 'package:mobile_pos/Screens/Settings/Help%20&%20Support/on_board.dart';
import 'package:mobile_pos/Screens/SplashScreen/splash_screen.dart';
import 'package:mobile_pos/app_init/app_init_bloc.dart';
import 'Screens/Authentication/bloc/bloc_auth_screen_bloc.dart';
import 'Screens/Authentication/profile_setup.dart';
import 'repositories/auth/auth_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  EquatableConfig.stringify = kDebugMode;
  // Activate app check after initialization, but before
  // usage of any Firebase services.
  await FirebaseAppCheck.instance.activate();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider<AuthRepository>(
          create: (_) => AuthRepository(),
        ),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(
            create: (context) => AppInitBloc(
              authRepository: context.read<AuthRepository>(),
            ),
          ),
          BlocProvider<BlocAuthScreenBloc>(
            create: (context) => BlocAuthScreenBloc(
              appInitBloc: context.read<AppInitBloc>(),
              authRepository: context.read<AuthRepository>(),
            ),
            child: const LoginForm(),
          )
        ],
        child: MaterialApp(
          title: 'SalesPro',
          initialRoute: '/',
          builder: EasyLoading.init(),
          routes: {
            '/': (context) => const SplashScreen(),
            '/onBoard': (context) => const OnBoard(),
            '/signIn': (context) => const SignInScreen(),
            LoginForm.routeName: (context) {
              return const LoginForm();
            },
            '/signup': (context) => const RegisterScreen(),
            '/otp': (context) => const OtpPage(),
            '/purchaseCustomer': (context) => const PurchaseContact(),
            '/forgotPassword': (context) => const ForgotPassword(),
            '/success': (context) => const SuccessScreen(),
            '/setupProfile': (context) => const ProfileSetup(),
            '/home': (context) => const Home(),
            '/profile': (context) => const ProfileScreen(),
            // ignore: missing_required_param
            '/Products': (context) => AddProduct(),
            '/SalesList': (context) => const SalesScreen(),
            // ignore: missing_required_param
            '/SalesDetails': (context) => SalesDetails(),
            // ignore: prefer_const_constructors
            '/salesCustomer': (context) => SalesContact(),
            '/addPromoCode': (context) => const AddPromoCode(),
            '/addDiscount': (context) => const AddDiscount(),
            '/Sales': (context) => SaleProducts(
                  catName: 'Laptop',
                ),
            '/Calculator': (context) => const CalculatorScreen(),
            '/Customer': (context) => const ContactList(),
            '/Expense': (context) => const ExpenseList(),
            '/Stock': (context) => const StockList(),
            '/Purchase': (context) => PurchaseScreen(
                  catName: 'Laptop',
                ),
            '/Delivery': (context) => const DeliveryAddress(),
            '/Reports': (context) => const Reports(),
            '/Marketing': (context) => const MarketingScreen(),
            '/PaymentOptions': (context) => const PaymentOptions(),
          },
        ),
      ),
    );
  }
}
