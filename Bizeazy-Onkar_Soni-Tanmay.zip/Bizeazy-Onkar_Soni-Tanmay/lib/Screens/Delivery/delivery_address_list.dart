import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/GlobalComponents/button_global.dart';
import 'package:mobile_pos/Screens/Delivery/Model/delivery_model.dart';
import 'package:mobile_pos/constant.dart';
import 'package:nb_utils/nb_utils.dart';
import 'add_delivery_location.dart';

class DeliveryAddress extends StatefulWidget {
  const DeliveryAddress({Key? key}) : super(key: key);

  @override
  _DeliveryAddressState createState() => _DeliveryAddressState();
}

class _DeliveryAddressState extends State<DeliveryAddress> {
  bool selected = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Delivery Address',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            FirebaseAnimatedList(
              defaultChild: Padding(
                padding: const EdgeInsets.only(top: 30.0, bottom: 30.0),
                child: Loader(color: Colors.white.withOpacity(0.2), size: 60,),
              ),
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              query: FirebaseDatabase.instance
                  .reference()
                  .child(FirebaseAuth.instance.currentUser!.uid)
                  .child('Delivery Addresses'),
              itemBuilder: (context, snapshot, animation, index) {
                final json = snapshot.value as Map<dynamic, dynamic>;
                final address = DeliveryModel.fromJson(json);
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Card(
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                        side: const BorderSide(color: Colors.white, width: 2.0),
                        borderRadius: BorderRadius.circular(15.0)),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20.0,top: 20.0,bottom: 10.0),
                          child: Row(
                            children: [
                              const Image(
                                image: AssetImage('images/officedeliver.png'),
                              ),
                              const SizedBox(
                                width: 15.0,
                              ),
                              Text(
                                '${address.firstName} / ${address.addressType}',
                                style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20.0,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 20.0),
                              child: SizedBox(
                                width: 200.0,
                                child: Text(
                                  address.addressLocation,
                                  maxLines: 2,
                                  style: GoogleFonts.poppins(
                                    color: kGreyTextColor,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 50.0,),
                            const Image(image: AssetImage('images/map.png'),height: 66.0,width: 66.0,),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 20.0,top: 10.0,bottom: 30.0),
                          child: Text(
                            address.phoneNumber,
                            style: GoogleFonts.poppins(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            ButtonGlobalWithoutIcon(
              buttontext: 'Add Delivery',
              buttonDecoration: kButtonDecoration.copyWith(color: kMainColor),
              onPressed: () {
                const AddDelivery().launch(context);
              },
              buttonTextColor: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
