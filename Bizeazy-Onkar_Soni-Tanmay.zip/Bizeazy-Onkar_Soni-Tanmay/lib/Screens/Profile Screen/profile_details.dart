import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/GlobalComponents/button_global.dart';
import 'package:mobile_pos/Screens/Authentication/login_form.dart';
import 'package:mobile_pos/Screens/Profile%20Screen/edit_profile.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../constant.dart';

class ProfileDetails extends StatefulWidget {
  const ProfileDetails({Key? key}) : super(key: key);

  @override
  _ProfileDetailsState createState() => _ProfileDetailsState();
}

class _ProfileDetailsState extends State<ProfileDetails> {
  String language = 'Loading';
  String businessCategory = 'Loading';
  String companyName = 'Loading';
  String phoneNumber = 'Loading';
  String countryName = 'Loading';
  String pictureUrl = 'https://i.imgur.com/jlyGd1j.jpg';

  Future<String> getEmail() async {
    EasyLoading.show(
      status: 'Loading... ',
      dismissOnTap: false,
    );
    String result = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/companyName')
            .once())
        .value;
    String category = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/businessCategory')
            .once())
        .value;
    String phone = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/phoneNumber')
            .once())
        .value;
    String lang = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/language')
            .once())
        .value;
    String country = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/countryName')
            .once())
        .value;
    String picture = (await FirebaseDatabase.instance
            .reference()
            .child(FirebaseAuth.instance.currentUser!.uid)
            .child('Personal Information/pictureUrl')
            .once())
        .value;
    setState(() {
      companyName = result.toString();
      businessCategory = category.toString();
      countryName = country.toString();
      phoneNumber = phone.toString();
      language = lang.toString();
      // ignore: unnecessary_null_comparison
      if (picture != null) {
        pictureUrl = picture.toString();
      }
      EasyLoading.showSuccess('Fetching Data Successful');
    });
    return result;
  }

  @override
  void initState() {
    getEmail();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Profile',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: GestureDetector(
              onTap: () {
                const EditProfile().launch(context);
              },
              child: Row(
                children: [
                  const Icon(
                    Icons.edit,
                    color: kMainColor,
                  ),
                  const SizedBox(
                    width: 5.0,
                  ),
                  Text(
                    'Edit',
                    style: GoogleFonts.poppins(
                      color: kMainColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: Container(
                  height: 100.0,
                  width: 100.0,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Image(
                    image: NetworkImage(pictureUrl),
                    height: 100.0,
                    width: 100.0,
                  ),
                ),
              ),
              const SizedBox(
                height: 10.0,
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: AppTextField(
                  readOnly: true,
                  cursorColor: kGreyTextColor,
                  controller: TextEditingController(
                    text: companyName,
                  ),
                  decoration: InputDecoration(
                      border: const OutlineInputBorder().copyWith(
                          borderSide: const BorderSide(color: kGreyTextColor)),
                      hoverColor: kGreyTextColor,
                      fillColor: kGreyTextColor),
                  textFieldType: TextFieldType.NAME,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: AppTextField(
                  readOnly: true,
                  cursorColor: kGreyTextColor,
                  controller: TextEditingController(
                    text: phoneNumber,
                  ),
                  decoration: InputDecoration(
                      border: const OutlineInputBorder().copyWith(
                          borderSide: const BorderSide(color: kGreyTextColor)),
                      hoverColor: kGreyTextColor,
                      fillColor: kGreyTextColor),
                  textFieldType: TextFieldType.NAME,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: AppTextField(
                  readOnly: true,
                  cursorColor: kGreyTextColor,
                  controller: TextEditingController(
                    text: businessCategory,
                  ),
                  decoration: InputDecoration(
                      border: const OutlineInputBorder().copyWith(
                          borderSide: const BorderSide(color: kGreyTextColor)),
                      hoverColor: kGreyTextColor,
                      fillColor: kGreyTextColor),
                  textFieldType: TextFieldType.NAME,
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  children: [
                    Expanded(
                      child: AppTextField(
                        readOnly: true,
                        cursorColor: kGreyTextColor,
                        controller: TextEditingController(
                          text: countryName,
                        ),
                        decoration: InputDecoration(
                            border: const OutlineInputBorder().copyWith(
                                borderSide:
                                    const BorderSide(color: kGreyTextColor)),
                            hoverColor: kGreyTextColor,
                            fillColor: kGreyTextColor),
                        textFieldType: TextFieldType.NAME,
                      ),
                    ),
                    const SizedBox(
                      width: 10.0,
                    ),
                    Expanded(
                      child: AppTextField(
                        readOnly: true,
                        cursorColor: kGreyTextColor,
                        controller: TextEditingController(
                          text: language,
                        ),
                        decoration: InputDecoration(
                            border: const OutlineInputBorder().copyWith(
                                borderSide:
                                    const BorderSide(color: kGreyTextColor)),
                            hoverColor: kGreyTextColor,
                            fillColor: kGreyTextColor),
                        textFieldType: TextFieldType.NAME,
                      ),
                    ),
                  ],
                ),
              ),
              ButtonGlobal(
                iconWidget: Icons.arrow_forward,
                buttontext: 'Change Password',
                iconColor: Colors.white,
                buttonDecoration: kButtonDecoration.copyWith(color: kMainColor),
                onPressed: () async {
                  try{
                    EasyLoading.show(status: 'Sending Email', dismissOnTap: false);
                    await FirebaseAuth.instance.sendPasswordResetEmail(
                      email: FirebaseAuth.instance.currentUser!.email.toString(),
                    );
                    EasyLoading.showSuccess('Email Sent! Check your Inbox');
                    const LoginForm().launch(context);
                    FirebaseAuth.instance.signOut();
                  } catch(e){
                    EasyLoading.showError(e.toString());
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
