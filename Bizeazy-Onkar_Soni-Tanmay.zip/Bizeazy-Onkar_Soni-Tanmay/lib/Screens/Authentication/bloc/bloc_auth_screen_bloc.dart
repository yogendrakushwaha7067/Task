import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:mobile_pos/app_init/app_init_bloc.dart';
import 'package:mobile_pos/repositories/auth/auth_repository.dart';

import '../../../models/models.dart';

part 'bloc_auth_screen_event.dart';
part 'bloc_auth_screen_state.dart';

class BlocAuthScreenBloc
    extends Bloc<BlocAuthScreenEvent, BlocAuthScreenState> {
  final AppInitBloc _appInitBloc;
  final AuthRepository _authRepository;
  BlocAuthScreenBloc({
    required AppInitBloc appInitBloc,
    required AuthRepository authRepository,
  })  : _appInitBloc = appInitBloc,
        _authRepository = authRepository,
        super(BlocAuthScreenState.initial());

  @override
  Stream<BlocAuthScreenState> mapEventToState(
      BlocAuthScreenEvent event) async* {
    if (event is EmailChanged) {
      yield* _mapToChangeEmail(event);
    } else if (event is PasswordChanged) {
      yield* _mapToChangePassword(event);
    } else if (event is LoginEvent) {
      yield* _mapToLogin(event);
    }
  }

  Stream<BlocAuthScreenState> _mapToChangeEmail(EmailChanged event) async* {
    yield state.copyWith(email: event.email);
  }

  Stream<BlocAuthScreenState> _mapToChangePassword(
      PasswordChanged event) async* {
    yield state.copyWith(password: event.password);
  }

  Stream<BlocAuthScreenState> _mapToLogin(LoginEvent event) async* {
    if (state.status == AuthStatus.loggingIn) return;
    yield state.copyWith(status: AuthStatus.loggingIn);
    try {
      await _authRepository.loginWithEmailAndPassword(
          email: state.email, password: state.password);
      yield state.copyWith(status: AuthStatus.loggingSuccess);
    } on Failure catch (err) {
      yield (state.copyWith(failure: err, status: AuthStatus.error));
    }
  }
}
