part of 'bloc_auth_screen_bloc.dart';

enum AuthStatus { initial, loggingIn, loggingSuccess, error }

class BlocAuthScreenState extends Equatable {
  final String email;
  final String password;
  final AuthStatus status;
  final Failure failure;

  const BlocAuthScreenState({
    required this.email,
    required this.password,
    required this.status,
    required this.failure,
  });

  factory BlocAuthScreenState.initial() {
    return const BlocAuthScreenState(
        email: '',
        failure: Failure(),
        password: '',
        status: AuthStatus.initial);
  }
  @override
  bool get stringify => true;

  @override
  List<Object> get props => [email, password, status, failure];

  BlocAuthScreenState copyWith({
    String? email,
    String? password,
    AuthStatus? status,
    Failure? failure,
  }) {
    return BlocAuthScreenState(
      email: email ?? this.email,
      password: password ?? this.password,
      status: status ?? this.status,
      failure: failure ?? this.failure,
    );
  }
}
