import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/GlobalComponents/button_global.dart';
import 'package:mobile_pos/Screens/Authentication/bloc/bloc_auth_screen_bloc.dart'
    as bl;
import 'package:nb_utils/nb_utils.dart';
import '../../constant.dart';
import '../../widgets/widgets.dart';
import 'bloc/bloc_auth_screen_bloc.dart';

class LoginForm extends StatefulWidget {
  static const String routeName = '"/loginForm"';
  const LoginForm({Key? key}) : super(key: key);

  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  FocusNode? _focusNode;
  @override
  void initState() {
    _focusNode = FocusNode();
    super.initState();
  }

  @override
  void dispose() {
    _focusNode?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          body: Center(
            child: SingleChildScrollView(
              child:
                  BlocConsumer<bl.BlocAuthScreenBloc, bl.BlocAuthScreenState>(
                listener: (context, state) {
                  if (state.status == bl.AuthStatus.error) {
                    showDialog(
                      context: (context),
                      builder: (context) =>
                          ErrorDialog(content: state.failure.message),
                    );
                  } else if (state.status == bl.AuthStatus.loggingSuccess) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Logged In'),
                        duration: Duration(seconds: 1),
                      ),
                    );
                    Navigator.of(context).pushNamed('/home');
                  }
                },
                builder: (context, state) {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset('images/logoandname.png'),
                      const SizedBox(
                        height: 30.0,
                      ),
                      Visibility(
                        visible: state.status == bl.AuthStatus.loggingIn,
                        child: const CircularProgressIndicator(
                          strokeWidth: 2,
                          color: kMainColor,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: SizedBox(
                          height: 60.0,
                          child: AppTextField(
                            textFieldType: TextFieldType.EMAIL,
                            onFieldSubmitted: (_) {
                              FocusNode().requestFocus(_focusNode);
                            },
                            textInputAction: TextInputAction.next,
                            onChanged: (value) {
                              context
                                  .read<BlocAuthScreenBloc>()
                                  .add(EmailChanged(email: value));
                            },
                            decoration: const InputDecoration(
                              labelText: 'Email Address',
                              hintText: 'example@example.com',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: AppTextField(
                          focus: _focusNode,
                          textInputAction: TextInputAction.done,
                          onChanged: (value) {
                            context
                                .read<BlocAuthScreenBloc>()
                                .add(bl.PasswordChanged(password: value));
                          }, // Optional
                          textFieldType: TextFieldType.PASSWORD,
                          decoration: const InputDecoration(
                            labelText: 'Password',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          const Spacer(),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(context, '/forgotPassword');
                            },
                            child: Text(
                              'Forgot Password?',
                              style: GoogleFonts.poppins(
                                color: kGreyTextColor,
                                fontSize: 15.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                      ButtonGlobalWithoutIcon(
                          buttontext: 'Log In',
                          buttonDecoration:
                              kButtonDecoration.copyWith(color: kMainColor),
                          onPressed: () {
                            context
                                .read<BlocAuthScreenBloc>()
                                .add(const LoginEvent());
                          },
                          buttonTextColor: Colors.white),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Haven\'t any account?',
                            style: GoogleFonts.poppins(
                                color: kGreyTextColor, fontSize: 15.0),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.pushNamed(context, '/signup');
                            },
                            child: Text(
                              'Register',
                              style: GoogleFonts.poppins(
                                color: kMainColor,
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
