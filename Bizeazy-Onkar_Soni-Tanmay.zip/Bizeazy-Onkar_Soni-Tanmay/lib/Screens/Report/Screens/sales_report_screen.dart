import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/Screens/Sales/Model/sales_report.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../../constant.dart';

class SalesReportScreen extends StatefulWidget {
  const SalesReportScreen({Key? key}) : super(key: key);

  @override
  _SalesReportScreenState createState() => _SalesReportScreenState();
}

class _SalesReportScreenState extends State<SalesReportScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Sales Report',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: Column(
        children: [
          Column(
            children: [
              const SizedBox(
                height: 10.0,
              ),
              // Row(
              //   children: [
              //     Expanded(
              //       child: Padding(
              //         padding: const EdgeInsets.all(4.0),
              //         child: AppTextField(
              //           textFieldType: TextFieldType.NAME,
              //           readOnly: true,
              //           onTap: () async {
              //             var date = await showDatePicker(
              //                 context: context,
              //                 initialDate: DateTime.now(),
              //                 firstDate: DateTime(1900),
              //                 lastDate: DateTime(2100));
              //             dateController.text =
              //                 date.toString().substring(0, 10);
              //           },
              //           controller: dateController,
              //           decoration: InputDecoration(
              //               border: OutlineInputBorder(),
              //               floatingLabelBehavior:
              //               FloatingLabelBehavior.always,
              //               labelText: 'Start Date',
              //               hintText: 'Pick Start Date'),
              //         ),
              //       ),
              //     ),
              //     Expanded(
              //       child: Padding(
              //         padding: const EdgeInsets.all(4.0),
              //         child: AppTextField(
              //           textFieldType: TextFieldType.OTHER,
              //           readOnly: true,
              //           onTap: () async {
              //             var date = await showDatePicker(
              //                 context: context,
              //                 initialDate: DateTime.now(),
              //                 firstDate: DateTime(1900),
              //                 lastDate: DateTime(2100));
              //             dateController.text =
              //                 date.toString().substring(0, 10);
              //           },
              //           controller: dateController,
              //           decoration: InputDecoration(
              //               border: OutlineInputBorder(),
              //               floatingLabelBehavior:
              //               FloatingLabelBehavior.always,
              //               labelText: 'End Date',
              //               hintText: 'Pick End Date'),
              //         ),
              //       ),
              //     ),
              //   ],
              // ),
              // SizedBox(
              //   height: 10.0,
              // ),
              DataTable(
                headingRowColor:
                MaterialStateColor.resolveWith((states) => kDarkWhite),
                columns: const <DataColumn>[
                  DataColumn(
                    label: Text(
                      'Customer Name',
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      'QTY',
                    ),
                  ),
                  DataColumn(
                    label: Text(
                      'Price',
                    ),
                  ),
                ],
                rows: const [],
              ),
              FirebaseAnimatedList(
                defaultChild: Padding(
                  padding: const EdgeInsets.only(top: 30.0, bottom: 30.0),
                  child: Loader(
                    color: Colors.white.withOpacity(0.2),
                    size: 60,
                  ),
                ),
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                query: FirebaseDatabase.instance
                    .reference()
                    .child(FirebaseAuth.instance.currentUser!.uid)
                    .child('Sales Report'),
                itemBuilder: (context, snapshot, animation, index) {
                  final json = snapshot.value as Map<dynamic, dynamic>;
                  final salesReport = SalesReport.fromJson(json);
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 4,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 15.0),
                            child: Text(
                              salesReport.customerName,
                              textAlign: TextAlign.start,
                              style: GoogleFonts.poppins(
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Text(
                            salesReport.purchaseQuantity,
                            style: GoogleFonts.poppins(
                              color: Colors.black,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            salesReport.purchasePrice,
                            style: GoogleFonts.poppins(
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
