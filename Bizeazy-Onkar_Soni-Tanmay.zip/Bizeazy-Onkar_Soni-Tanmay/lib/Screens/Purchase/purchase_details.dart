import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cart/flutter_cart.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/GlobalComponents/button_global.dart';
import 'package:mobile_pos/Screens/Payment/payment_options.dart';
import 'package:mobile_pos/Screens/Purchase/Model/purchase_report.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../constant.dart';

// ignore: must_be_immutable
class PurchaseDetails extends StatefulWidget {
  PurchaseDetails({Key? key, @required this.customerName}) : super(key: key);
  // ignore: prefer_typing_uninitialized_variables
  var customerName;
  @override
  _PurchaseDetailsState createState() => _PurchaseDetailsState();
}

class _PurchaseDetailsState extends State<PurchaseDetails> {
  var cart = FlutterCart();
  String customer = '';
  @override
  void initState() {
    widget.customerName == null
        ? customer = 'Unknown'
        : customer = widget.customerName;
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Purchase Details',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
        actions: [
          PopupMenuButton(
            itemBuilder: (BuildContext bc) => [
              const PopupMenuItem(
                  child: Text('Add Customer'), value: "/purchaseCustomer"),
              const PopupMenuItem(
                  child: Text('Add Discount'), value: "/addDiscount"),
              const PopupMenuItem(
                  child: Text('Cancel All Product'), value: "/settings"),
              const PopupMenuItem(
                  child: Text('Vat Doesn\'t Apply'), value: "/settings"),
            ],
            onSelected: (value) {
              Navigator.pushNamed(context, '$value');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(
            height: 30.0,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: cart.cartItem.length,
              itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.only(
                    left: 25.0, right: 25.0, bottom: 10.0),
                child: Row(
                  children: [
                    Text(
                      cart.cartItem[index].productName.toString(),
                      style: GoogleFonts.poppins(
                        color: kGreyTextColor,
                        fontSize: 15.0,
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '\$${cart.cartItem[index].unitPrice.toString()}',
                      style: GoogleFonts.poppins(
                        color: kGreyTextColor,
                        fontSize: 15.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const Divider(
            color: kGreyTextColor,
            thickness: 0.5,
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 25.0, right: 25.0, bottom: 10.0),
            child: Row(
              children: [
                Text(
                  'Subtotal',
                  style: GoogleFonts.poppins(
                    color: kGreyTextColor,
                    fontSize: 15.0,
                  ),
                ),
                const Spacer(),
                Text(
                  cart.getTotalAmount().toString(),
                  style: GoogleFonts.poppins(
                    color: kGreyTextColor,
                    fontSize: 15.0,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding:
                const EdgeInsets.only(left: 25.0, right: 25.0, bottom: 10.0),
            child: Row(
              children: [
                Text(
                  'Discount',
                  style: GoogleFonts.poppins(
                    color: kGreyTextColor,
                    fontSize: 15.0,
                  ),
                ),
                const Spacer(),
                Text(
                  '00',
                  style: GoogleFonts.poppins(
                    color: kGreyTextColor,
                    fontSize: 15.0,
                  ),
                ),
              ],
            ),
          ),
          const Divider(
            color: kGreyTextColor,
            thickness: 0.5,
          ),
          Container(
            height: 50,
            width: MediaQuery.of(context).size.width,
            color: kDarkWhite,
            child: Padding(
              padding:
                  const EdgeInsets.only(left: 25.0, right: 25.0, bottom: 10.0),
              child: Row(
                children: [
                  Text(
                    'Total',
                    style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 15.0,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    cart.getTotalAmount().toString(),
                    style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 15.0,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Spacer(),
          ButtonGlobal(
            iconWidget: Icons.arrow_forward,
            buttontext: 'Continue',
            iconColor: Colors.white,
            buttonDecoration: kButtonDecoration.copyWith(color: kMainColor),
            onPressed: () async {
              try{
                EasyLoading.show(status: 'Loading...',dismissOnTap: false);
                final DatabaseReference _purchaseReportRef =
                FirebaseDatabase.instance
                    .reference()
                    .child(FirebaseAuth.instance.currentUser!.uid)
                    .child('Purchase Report');
                PurchaseReport purchaseReport = PurchaseReport(customer, cart.getTotalAmount().toString(), cart.getCartItemCount().toString());
                await _purchaseReportRef.push().set(purchaseReport.toJson());
                EasyLoading.dismiss();
                const PaymentOptions().launch(context);
              } catch (e) {
                EasyLoading.dismiss();
                ScaffoldMessenger.of(context)
                    .showSnackBar(SnackBar(content: Text(e.toString())));
              }
            },
          ),
        ],
      ),
    );
  }
}
