import 'package:flutter/material.dart';
import 'package:flutter_cart/flutter_cart.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/Screens/Sales/sales_details.dart';
import 'package:nb_utils/nb_utils.dart';
import '../../constant.dart';
import 'package:math_expressions/math_expressions.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({Key? key}) : super(key: key);

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  int productCount = 0;
  String _expression = '';
  String productName = 'Custom';
  String total = 'Cart Is Empty';
  var cart = FlutterCart();
  final productNameController = TextEditingController();
  void numClick(String text) {
    setState(() => _expression += text);
  }

  void evaluate(String text) {
    Parser p = Parser();
    Expression exp = p.parse(_expression);
    ContextModel cm = ContextModel();

    setState(() {
      productNameController.clear();
      _expression = exp.evaluate(EvaluationType.REAL, cm).toString();
      cart.addToCart(productId: productName, productName: productName, unitPrice: exp.evaluate(EvaluationType.REAL, cm));
      total = cart.getTotalAmount().toString();
      productCount++;
      _expression = '';
    });
  }
  void clear(String text) {
    setState(() {
      _expression = '';
      cart.deleteAllCart();
      total = 'Cart Is Empty';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          'Calculator',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
        actions: [
          PopupMenuButton(
            itemBuilder: (BuildContext bc) => [
              PopupMenuItem(
                child: Row(
                  children: [
                    const Icon(
                      Icons.add_to_photos,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Add Product',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/Products",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const Icon(
                      Icons.card_travel,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Stock List',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/Stock",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const  Icon(
                      Icons.text_snippet_outlined,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Sales List',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/SalesList",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const  Icon(
                      Icons.person_add,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Add Contact',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/SalesList",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const  Icon(
                      Icons.person_rounded,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Contact List',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/SalesList",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const  Icon(
                      Icons.list_sharp,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'Due List',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/SalesList",
              ),
              PopupMenuItem(
                child: Row(
                  children: [
                    const  Icon(
                      Icons.play_circle_outline,
                      color: kGreyTextColor,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: Text(
                        'How to use',
                        style: GoogleFonts.poppins(
                          fontSize: 18.0,
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
                value: "/SalesList",
              ),
            ],
            onSelected: (value) {
              Navigator.pushNamed(context, '$value');
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: () {
                // ignore: missing_required_param
                SalesDetails().launch(context);
              },
              child: Container(
                height: 60.0,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: kMainColor,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          const Image(
                            image: AssetImage('images/selected.png'),
                          ),
                          Text(
                            productCount.toString(),
                            style: GoogleFonts.poppins(
                              fontSize: 15.0,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Center(
                        child: Text(
                          'Total: \$$total',
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                    const Expanded(
                      flex: 1,
                      child: Icon(
                        Icons.arrow_forward,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const Spacer(),
            Row(
              children: [
                Expanded(
                  child: AppTextField(
                    textFieldType: TextFieldType.NAME,
                    controller: productNameController,
                    onChanged: (value){
                      setState(() {
                        productName = value;
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Product Name',
                      labelStyle: GoogleFonts.poppins(
                        color: Colors.black,
                      ),
                      border: const OutlineInputBorder(),
                      fillColor: kMainColor.withOpacity(0.1),
                      filled: true,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 50.0,
                ),
                Expanded(
                  child: AppTextField(
                    textFieldType: TextFieldType.PHONE,
                    readOnly: true,
                    controller: TextEditingController(text: '\$$_expression'),
                    decoration: InputDecoration(
                      border: const OutlineInputBorder(),
                      fillColor: kMainColor.withOpacity(0.1),
                      filled: true,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10.0,
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height/2,
              width: MediaQuery.of(context).size.width,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      CalcButton(
                        text: '7',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '8',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '9',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: 'C',
                        callback: clear,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      CalcButton(
                        text: '4',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '5',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '6',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '*',
                        callback: numClick,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      CalcButton(
                        text: '1',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '2',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '3',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '+',
                        callback: numClick,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      CalcButton(
                        text: '.',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '0',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '%',
                        callback: numClick,
                      ),
                      CalcButton(
                        text: '=',
                        callback: evaluate,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class CalcButton extends StatelessWidget {
  final String text;
  final Color textColor;
  final Function callback;

  const CalcButton({
    Key? key,
    required this.text,
    this.textColor = Colors.black,
    required this.callback,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(10),
      child: SizedBox(
        width: 65,
        height: 65,
        // ignore: deprecated_member_use
        child: FlatButton(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(50.0),
          ),
          onPressed: () {
            callback(text);
          },
          child: Text(
            text,
            style: GoogleFonts.rubik(
              textStyle: const TextStyle(
                fontSize: 20,
              ),
            ),
          ),
          color: Colors.white,
          textColor: textColor,
        ),
      ),
    );
  }
}