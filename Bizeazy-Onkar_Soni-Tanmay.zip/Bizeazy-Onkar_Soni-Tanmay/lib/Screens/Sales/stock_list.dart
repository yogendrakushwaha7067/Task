import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/ui/firebase_animated_list.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mobile_pos/Screens/Products/Model/product_model.dart';
import 'package:nb_utils/nb_utils.dart';

import '../../constant.dart';

class StockList extends StatefulWidget {
  const StockList({Key? key}) : super(key: key);

  @override
  _StockListState createState() => _StockListState();
}

class _StockListState extends State<StockList> {
  final dateController = TextEditingController();

  @override
  void dispose() {
    dateController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Stock List',
          style: GoogleFonts.poppins(
            color: Colors.black,
            fontSize: 20.0,
          ),
        ),
        iconTheme: const IconThemeData(color: Colors.black),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Column(
              children: [
                const SizedBox(
                  height: 10.0,
                ),
                // Row(
                //   children: [
                //     Expanded(
                //       child: Padding(
                //         padding: const EdgeInsets.all(4.0),
                //         child: AppTextField(
                //           textFieldType: TextFieldType.NAME,
                //           readOnly: true,
                //           onTap: () async {
                //             var date = await showDatePicker(
                //                 context: context,
                //                 initialDate: DateTime.now(),
                //                 firstDate: DateTime(1900),
                //                 lastDate: DateTime(2100));
                //             dateController.text =
                //                 date.toString().substring(0, 10);
                //           },
                //           controller: dateController,
                //           decoration: InputDecoration(
                //               border: OutlineInputBorder(),
                //               floatingLabelBehavior:
                //               FloatingLabelBehavior.always,
                //               labelText: 'Start Date',
                //               hintText: 'Pick Start Date'),
                //         ),
                //       ),
                //     ),
                //     Expanded(
                //       child: Padding(
                //         padding: const EdgeInsets.all(4.0),
                //         child: AppTextField(
                //           textFieldType: TextFieldType.OTHER,
                //           readOnly: true,
                //           onTap: () async {
                //             var date = await showDatePicker(
                //                 context: context,
                //                 initialDate: DateTime.now(),
                //                 firstDate: DateTime(1900),
                //                 lastDate: DateTime(2100));
                //             dateController.text =
                //                 date.toString().substring(0, 10);
                //           },
                //           controller: dateController,
                //           decoration: InputDecoration(
                //               border: OutlineInputBorder(),
                //               floatingLabelBehavior:
                //               FloatingLabelBehavior.always,
                //               labelText: 'End Date',
                //               hintText: 'Pick End Date'),
                //         ),
                //       ),
                //     ),
                //   ],
                // ),
                // SizedBox(
                //   height: 10.0,
                // ),
                DataTable(
                  horizontalMargin: 10.0,
                  columnSpacing: 50.0,
                  headingRowColor:
                      MaterialStateColor.resolveWith((states) => kDarkWhite),
                  columns: const <DataColumn>[
                    DataColumn(
                      label: Text(
                        'Product',
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Category',
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'QTY',
                      ),
                    ),
                    DataColumn(
                      label: Text(
                        'Price',
                      ),
                    ),
                  ],
                  rows: const [],
                ),
                FirebaseAnimatedList(
                  defaultChild: Padding(
                    padding: const EdgeInsets.only(top: 30.0, bottom: 30.0),
                    child: Loader(
                      color: Colors.white.withOpacity(0.2),
                      size: 60,
                    ),
                  ),
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  query: FirebaseDatabase.instance
                      .reference()
                      .child(FirebaseAuth.instance.currentUser!.uid)
                      .child('Products'),
                  itemBuilder: (context, snapshot, animation, index) {
                    final json = snapshot.value as Map<dynamic, dynamic>;
                    final product = ProductModel.fromJson(json);
                    return Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  product.productName,
                                  textAlign: TextAlign.start,
                                  style: GoogleFonts.poppins(
                                    color: product.productStock.toInt() < 20
                                        ? Colors.red
                                        : Colors.black,
                                    fontSize: 12.0,
                                  ),
                                ),
                                Text(
                                  product.brandName,
                                  textAlign: TextAlign.start,
                                  style: GoogleFonts.poppins(
                                    color: product.productStock.toInt() < 20
                                        ? Colors.red
                                        : kGreyTextColor,
                                    fontSize: 10.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Text(product.productCategory,style: GoogleFonts.poppins(
                              color: product.productStock.toInt() < 20
                                  ? Colors.red
                                  : Colors.black,
                            ),),
                          ),
                          Expanded(
                              child: Text(
                            product.productStock,
                            style: GoogleFonts.poppins(
                              color: product.productStock.toInt() < 20
                                  ? Colors.red
                                  : Colors.black,
                            ),
                          )),
                          Expanded(
                            child: Text(
                              '\$${product.productSalePrice}',
                              style: GoogleFonts.poppins(
                                color: product.productStock.toInt() < 20
                                    ? Colors.red
                                    : Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
