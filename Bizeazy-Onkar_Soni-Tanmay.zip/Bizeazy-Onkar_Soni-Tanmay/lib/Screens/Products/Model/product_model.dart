class ProductModel {
  late String productName,
      productCategory,
      brandName,
      productCode,
      productStock,
      productUnit,
      productSalePrice,
      productDiscount,
      productWholeSalePrice,
      productDealerPrice,
      productManufacturer,
      productPicture;

  ProductModel(
      this.productName,
      this.productCategory,
      this.brandName,
      this.productCode,
      this.productStock,
      this.productUnit,
      this.productSalePrice,
      this.productDiscount,
      this.productWholeSalePrice,
      this.productDealerPrice,
      this.productManufacturer,
      this.productPicture);


  ProductModel.fromJson(Map<dynamic, dynamic> json)
      : productName = json['productName'] as String,
        productCategory = json['productCategory'] as String,
        brandName = json['brandName'] as String,
        productCode = json['productCode'] as String,
        productStock = json['productStock'] as String,
        productUnit = json['productUnit'] as String,
        productSalePrice = json['productSalePrice'] as String,
        productDiscount = json['productDiscount'] as String,
        productWholeSalePrice = json['productWholeSalePrice'] as String,
        productDealerPrice = json['productDealerPrice'] as String,
        productManufacturer = json['productManufacturer'] as String,
        productPicture = json['productPicture'] as String;

  Map<dynamic, dynamic> toJson() => <dynamic, dynamic>{
    'productName': productName,
    'productCategory': productCategory,
    'brandName': brandName,
    'productCode': productCode,
    'productStock': productStock,
    'productUnit': productUnit,
    'productSalePrice': productSalePrice,
    'productDiscount': productDiscount,
    'productWholeSalePrice': productWholeSalePrice,
    'productDealerPrice': productDealerPrice,
    'productManufacturer': productManufacturer,
    'productPicture': productPicture,
  };
}
