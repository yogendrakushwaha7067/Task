

class CustomerModel {
  late String customerName,
      phoneNumber,
      type,
      profilePicture,
      customerAddress,
      note;

  CustomerModel(this.customerName, this.phoneNumber, this.type,
      this.profilePicture, this.customerAddress, this.note);

  CustomerModel.fromJson(Map<dynamic, dynamic> json)
      : customerName = json['customerName'] as String,
        phoneNumber = json['phoneNumber'] as String,
        type = json['type'] as String,
        profilePicture = json['profilePicture'] as String,
        customerAddress = json['customerAddress'] as String,
        note = json['note'] as String;

  Map<dynamic, dynamic> toJson() => <dynamic, dynamic>{
        'customerName': customerName,
        'phoneNumber': phoneNumber,
        'type': type,
        'profilePicture': profilePicture,
        'customerAddress': customerAddress,
        'note': note,
      };
}
