package com.maantheme.mobilepos.mobile_pos;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
